package ee.learn.webstore.exceptions;

public class ProductNameLengthException extends Exception {
}
