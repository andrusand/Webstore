package ee.learn.webstore.dto;


import lombok.Data;

@Data
public class ProductSearchDTO {
    String description;
}
